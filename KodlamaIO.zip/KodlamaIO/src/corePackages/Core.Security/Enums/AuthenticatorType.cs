﻿namespace Core.Security.Enums;

public enum AuthenticatorType
{
    None = 0,
    Email = 1,
    Otp = 2
}